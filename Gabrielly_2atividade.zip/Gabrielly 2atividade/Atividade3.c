#include <stdio.h>

    int main(){
     printf("Impressao dos valores: \n\n");
int numero1 = 40;
int numero2 = 3;
     int soma = numero1 + numero2;
     int Subtracao = numero1 - numero2;
     float Divisao = numero1 / numero2;
     int Multiplicacao = numero1 * numero2;
     int Resto = numero1 %numero2; 

     printf ("Soma = %d\n\n", soma);
     printf ("Subtracao = %d\n\n", Subtracao);
     printf ("Divisao = %.2f\n\n", Divisao);
     printf ("Multiplicacao = %d\n\n", Multiplicacao);
     printf ("Resto = %d\n\n", Resto);



    }